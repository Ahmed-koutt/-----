
import { GoogleGenAI, Type } from "@google/genai";
import { Question, QuestionType, Difficulty } from "../types";

// استخدام Gemini 3 Pro - النموذج الأقوى للعمليات المعقدة
const MODEL_NAME = "gemini-3-pro-preview";
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateQuestions = async (
  content: string,
  type: QuestionType,
  difficulty: Difficulty,
  count: number,
  chapter?: string
): Promise<Question[]> => {
  const prompt = `أنت الخبير التعليمي المعتمد على تقنية Gemini 3 Pro. 
  المحتوى الكلي: "${content}"
  التركيز على الفصل/الموضوع: "${chapter || 'كامل المحتوى'}"
  
  المطلوب: إنشاء ${count} أسئلة تعليمية عالية الجودة.
  - مستوى الصعوبة المطلوب: ${difficulty}.
  - نوع الأسئلة: ${type === 'mix' ? 'مزيج من الاختياري والصواب والخطأ' : type === 'mcq' ? 'اختيار من متعدد' : 'صواب وخطأ'}.
  
  يجب أن يكون الرد بتنسيق JSON حصراً كـ Array تحتوي على كائنات بالخصائص التالية:
  - id: رقم تسلسلي
  - type: 'mcq' أو 'tf'
  - text: نص السؤال بالعربية الفصحى
  - options: (فقط للـ mcq) قائمة من 4 خيارات
  - answer: الإجابة الصحيحة`;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 32768 },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.NUMBER },
              type: { type: Type.STRING },
              text: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              answer: { type: Type.STRING }
            },
            required: ["id", "type", "text", "answer"]
          }
        }
      }
    });

    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Gemini Error (Questions):", error);
    return [];
  }
};

export const getChatResponse = async (
  message: string,
  context: string
) => {
  const chat = ai.chats.create({
    model: MODEL_NAME,
    config: {
      thinkingConfig: { thinkingBudget: 32768 },
      systemInstruction: `أنت "Gemini الخبير التعليمي الذكي". 
      سياق المستخدم: ${context}.
      أجب بذكاء واحترافية بالعربية الفصحى. ساعد الطالب في فهم الفصل المحدد والأسئلة التي تم إنشاؤها.`,
    }
  });

  try {
    const response = await chat.sendMessage({ message });
    return response.text;
  } catch (error) {
    console.error("Gemini Error (Chat):", error);
    return "أعتذر، واجه Gemini صعوبة في معالجة طلبك.";
  }
};
